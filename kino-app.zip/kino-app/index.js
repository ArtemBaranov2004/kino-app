// scripts.js
$(document).ready(function() {
    const sessionTimes = ["10:00", "12:00", "14:00", "16:00", "18:00", "20:00"];
    const today = new Date();
    const oneWeekAgo = new Date(today);
    oneWeekAgo.setDate(today.getDate() - 7);
    const oneWeekAhead = new Date(today);
    oneWeekAhead.setDate(today.getDate() + 7);

    // Set min and max dates for date picker
    $('#date').attr('min', formatDate(oneWeekAgo));
    $('#date').attr('max', formatDate(oneWeekAhead));

    // Populate session times
    sessionTimes.forEach(time => {
        $('#session').append(`<option value="${time}">${time}</option>`);
    });

    // Load data from LocalStorage
    const reservations = JSON.parse(localStorage.getItem('reservations')) || {};

    // Handle date change
    $('#date').on('change', function() {
        const selectedDate = $(this).val();
        loadSessions(selectedDate);
    });

    // Handle session change
    $('#session').on('change', function() {
        const selectedDate = $('#date').val();
        const selectedTime = $(this).val();
        loadSeats(selectedDate, selectedTime);
    });

    // Handle seat selection
    $('#seats').on('click', '.seat', function() {
        if ($(this).hasClass('booked')) return;
        $(this).toggleClass('selected');
        updateReservations();
    });

    function loadSessions(date) {
        const selectedDate = new Date(date);
        if (selectedDate < today) {
            $('#session').prop('disabled', true);
            loadSeats(date, null);
        } else {
            $('#session').prop('disabled', false);
            $('#session').val(sessionTimes[0]);
            loadSeats(date, sessionTimes[0]);
        }
    }

    function loadSeats(date, time) {
        $('#seats').empty();
        for (let i = 0; i < 100; i++) {
            const seat = $('<div class="seat"></div>');
            const seatKey = `${date}_${time}_${i}`;
            if (reservations[seatKey]) {
                seat.addClass('booked');
            }
            $('#seats').append(seat);
        }
    }

    function updateReservations() {
        const selectedDate = $('#date').val();
        const selectedTime = $('#session').val();
        if (!selectedDate || !selectedTime) return;

        $('#seats .seat').each(function(index) {
            const seatKey = `${selectedDate}_${selectedTime}_${index}`;
            if ($(this).hasClass('selected')) {
                reservations[seatKey] = true;
            } else {
                delete reservations[seatKey];
            }
        });

        localStorage.setItem('reservations', JSON.stringify(reservations));
    }

    function formatDate(date) {
        const d = new Date(date);
        const month = '' + (d.getMonth() + 1);
        const day = '' + d.getDate();
        const year = d.getFullYear();

        return [year, month.padStart(2, '0'), day.padStart(2, '0')].join('-');
    }

    // Initialize with today's date
    $('#date').val(formatDate(today)).trigger('change');
});
